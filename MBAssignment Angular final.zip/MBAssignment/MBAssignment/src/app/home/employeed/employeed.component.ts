import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Employee } from 'src/app/model/employeeTo';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ResultMessage } from 'src/app/model/REsultMessage';
import { AlertPopupComponent } from 'src/app/components/alert-popup/alert-popup.component';


@Component({
  selector: 'app-employeed',
  templateUrl: './employeed.component.html',
  styleUrls: ['./employeed.component.css']
})
export class EmployeedComponent implements OnInit {

  employeeList : Employee[]=[];
  employeeTo : Employee = {};
  reactiveForm: any;
  isAdd : boolean = true
  backupList : Employee[]=[];
  resultMessage : ResultMessage = {};
  tempEmployeeId? : number;
  @ViewChild(AlertPopupComponent) alertBox? :AlertPopupComponent
  searchquery? : any;
  idfordelete : any;
  constructor(private _employeeservice : EmployeeService,private _fb : FormBuilder) { }

  ngOnInit(): void {
    this.reactiveForm = this._fb.group({
      firstName: [null, [Validators.required, Validators.minLength(2)]],
      lastName: [null, [Validators.required, Validators.minLength(2)]],
      birthDate: [null, Validators.required],
      mobile: [null, [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      address: [null, [Validators.required, Validators.minLength(10)]],
      city: [null, Validators.required],
    })
    this.getEmployeeList();
  }

  getEmployeeList(){
    this.employeeList = []
    debugger
    this._employeeservice.getEmployeeList().subscribe(

      data =>{ 
        this.employeeList = data;
        this.backupList = data;


      },
      error=>{ 
        console.log(error) 
      })

  }

  addEmployee(){
    console.log(this.reactiveForm);
    this._employeeservice.addEmployeeDetails(this.employeeTo).subscribe(
      data =>{ 
        debugger
        this.resultMessage = data;
        this.alertBox?.openAlertPopup(this.resultMessage.resultMsg);
        this.getEmployeeList();
      },

      error=>{         
        this.alertBox?.openAlertPopup("Error - Something went wrong"); 
    })
  }

  updateEmployeeDetails(){
    debugger
    console.log(this.reactiveForm)
    this._employeeservice.updateEmployeeDetails(this.employeeTo).subscribe(
      data =>{ 
        debugger
        this.resultMessage = data;
        this.alertBox?.openAlertPopup(this.resultMessage.resultMsg);
        this.getEmployeeList();
      },    
      error=>{ 
        debugger
        this.alertBox?.openAlertPopup("Error - Something went wrong"); 
      })
  }

  deleteEmployeeDetails(){
    debugger
    if(this.idfordelete>0){
      this._employeeservice.deleteEmployeeDetails(this.idfordelete).subscribe(
        data =>{ 
          debugger
          this.resultMessage = data;
          this.alertBox?.openAlertPopup(this.resultMessage.resultMsg);
          this.getEmployeeList();      
        },
        error=>{ 
          this.alertBox?.openAlertPopup("Error - Something went wrong"); 
        })
    }
  }


  getEmployeeById(id?:number){
    debugger
    this._employeeservice.getEmployeeById(id).subscribe(
      data=>{
        this.employeeTo = data;
      },
      error=>{ console.log(error) }
    )
  }


  
  get firstName() {
    return this.reactiveForm.get('firstName');
  }

  get lastName() {
    return this.reactiveForm.get('lastName');
  }

  get city() {
    return this.reactiveForm.get('city');
  }

  get address() {
    return this.reactiveForm.get('address');
  }

  get mobile() {
    return this.reactiveForm.get('mobile');
  }

  get birthDate() {
    return this.reactiveForm.get('birthDate');
  }


  searchEmployee(){
    debugger
    this.employeeList = this.backupList
    this.searchquery = this.searchquery.replace(/\s/g, "")
    if(this.searchquery != null && this.searchquery != undefined && this.searchquery !=''){
      if(this.employeeList != null && this.employeeList != undefined && this.employeeList.length>0){
        this.employeeList = this.employeeList.filter(emp=> emp.firstName?.toLowerCase().includes(this.searchquery.toLowerCase()))
      }

    }

  }


  

}

