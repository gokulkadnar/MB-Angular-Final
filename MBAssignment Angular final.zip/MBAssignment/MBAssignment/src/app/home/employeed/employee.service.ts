import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Employee } from 'src/app/model/employeeTo';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  // home url
  private homeUrl: string = "http://localhost:8080/";

   header = new HttpHeaders().set("Authorization", 'Bearer ' + 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzYW5nZWV0YS5rQGdtYWlsLmNvbSIsImV4cCI6MTYyMjE2NDQyNiwiaWF0IjoxNjIyMTI4NDI2fQ.5C7ZQQP30w76ZsQZnyDskYu8FD7Cs_eddKQ66QWTKNA');

  constructor(private http: HttpClient) { }

  // get all employee list

  
  getEmployeeList() {
    let headers = new HttpHeaders()
  .set('Authorization', 'Bearer ' + '');

    return this.http.get<Employee[]>(this.homeUrl + 'employees');
  }

  //Add employee details
  addEmployeeDetails(employeeTo: Employee) {
    return this.http.post(this.homeUrl + 'save', employeeTo)
  }

  //update employee details
  updateEmployeeDetails(employeeTo: Employee) {
    return this.http.put(this.homeUrl + 'update', employeeTo);
  }

  //delete employee details
  deleteEmployeeDetails(id?: number) {
    return this.http.delete(this.homeUrl + 'delete/' + id);
  }


  //get employee details by id
  getEmployeeById(id?: number) {
    return this.http.get(this.homeUrl + 'employee/' + id);
  }

}

