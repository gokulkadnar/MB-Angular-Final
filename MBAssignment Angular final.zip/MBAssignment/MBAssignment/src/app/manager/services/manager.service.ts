import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserTo } from 'src/app/model/loginTo';
import { Manager } from 'src/app/model/managerTO';

@Injectable({
  providedIn: 'root'
})
export class ManagerService {

  constructor(private http: HttpClient) { }

  // Login user with user credential
  login(loginTo: UserTo) {
    return this.http.post('login', loginTo);
  }

  // sign up manager with details
  signUp(managerTo: Manager) {
    return this.http.post('signup', managerTo);
  }
}
