export class Employee
{
    public id? : number;
    public firstName? : string;
    public lastName? : string;
    public address? : string;
    public birthDate? : Date;
    public mobile? : number;
    public city? : string;
}