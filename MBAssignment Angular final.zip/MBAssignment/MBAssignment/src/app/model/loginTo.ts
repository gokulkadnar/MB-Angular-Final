import { Manager } from "./managerTO";

export class UserTo {
    email?: string;
    password?: string;
    managerInfo?: Manager;
    infoMsg?: string;
    status?: number;

}